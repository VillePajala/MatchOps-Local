# Security Advisories

All dependencies were audited using `npm audit fix` on 2025-07-21.

No remaining vulnerabilities were found after applying the recommended fixes.

